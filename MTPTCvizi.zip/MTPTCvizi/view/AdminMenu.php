<div class="row" >
	<div class="col-md-3 col-ms-3 col-mx-3"><p class="button" id="b1"><a href="index.php?enregistrement"><img src="view/image/en1.png" width="30%"><br/>ENREGISTRER VISITEUR</a></p></div>

	<div class="col-md-5">
		<h3>LISTE UTILISATEUR DANS LE BATIMENT</h3>
		<div id="liste">
		
		</div>
		<button class="btn" id="btn2" type="submit">Liste-Complete</button>
	</div>

	<div class="col-md-3"><p class="button" id="b3"><a href="index.php?rapport"><img src="view/image/rap1.png" width="30%"><br/>RAPPORT</p></div>

	<div class="col-md-3"><p class="button" id="b4"><a href="index.php?recherche"><img src="view/image/re1.png" width="30%"><br/>RECHERCHER VISITEUR</p></div>
</div>