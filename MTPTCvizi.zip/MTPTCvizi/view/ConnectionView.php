<div id="bar" class="container-fluid">
	<p><img src="view/image/palm.png"></p>
</div>
<div class="container-fluid">
	<div class="row">
		<div id="block" class="col-md-12">
			<p><img src="view/image/logo.png"></p>
		</div>
		<div id="block1" class="col-md-4">
			<p class="img"><img src="view/image/user.png"></p>
			<form method="post" action="">
				<P><input type="text" name="user" placeholder="Nom utilisateur" minlength="5" maxlength="10" size="30"/></P>
				<p><input type="password" name="password" placeholder="Mot de passe" minlength="8" maxlength="15" size="30"></p>
				<p><input type="submit" value="CONNEXION" class="btn"></p>
			</form>
		</div>
	</div>
</div>